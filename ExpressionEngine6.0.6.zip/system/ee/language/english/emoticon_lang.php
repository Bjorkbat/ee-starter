<?php

$lang = array(

    'emoticon_alt' => 'Alt tag',

    'emoticon_glyph' => 'Glyph',

    'emoticon_heading' => 'Emoticons',

    'emoticon_height' => 'Height',

    'emoticon_image' => 'Image',

    'emoticon_module_description' => 'Emoticon (smiley) module',

    'emoticon_module_name' => 'Emoticon',

    'emoticon_width' => 'Width',

);

// EOF
