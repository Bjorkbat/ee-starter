<?php

$lang = array(

    'ut_array' => 'Array',

    'ut_boolean' => 'Boolean',

    'ut_double' => 'Float', // can be the same as float
    'ut_failed' => 'Failed',

    'ut_file' => 'File Name',

    'ut_float' => 'Float',

    'ut_integer' => 'Integer',

    'ut_line' => 'Line Number',

    'ut_notes' => 'Notes',

    'ut_null' => 'Null',

    'ut_object' => 'Object',

    'ut_passed' => 'Passed',

    'ut_res_datatype' => 'Expected Datatype',

    'ut_resource' => 'Resource',

    'ut_result' => 'Result',

    'ut_string' => 'String',

    'ut_test_datatype' => 'Test Datatype',

    'ut_test_name' => 'Test Name',

    'ut_undefined' => 'Undefined Test Name',

);

// EOF
