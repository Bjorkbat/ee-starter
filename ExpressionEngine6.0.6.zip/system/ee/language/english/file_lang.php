<?php

$lang = array(

    'content_files' => 'Files',

    'file_module_description' => 'File module',

    'file_module_name' => 'File',

);

// EOF
