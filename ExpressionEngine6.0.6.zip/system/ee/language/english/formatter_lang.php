<?php

$lang = array(

    'formatter_bytes' => 'bytes',

    'formatter_bytes_abbr' => 'B',

    'formatter_bytes_abbr_html' => '<abbr title="Bytes">B</abbr>',

    'formatter_duration_seconds_only' => '%d sec.',

    'formatter_gigabytes' => 'gigabytes',

    'formatter_gigabytes_abbr' => 'GB',

    'formatter_gigabytes_abbr_html' => '<abbr title="Gigabytes">GB</abbr>',

    'formatter_kilobytes' => 'kilobytes',

    'formatter_kilobytes_abbr' => 'KB',

    'formatter_kilobytes_abbr_html' => '<abbr title="Kilobytes">KB</abbr>',

    'formatter_megabytes' => 'megabytes',

    'formatter_megabytes_abbr' => 'MB',

    'formatter_megabytes_abbr_html' => '<abbr title="Megabytes">MB</abbr>',

);

// EOF
