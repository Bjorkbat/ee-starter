<?php

$lang = array(

    'bytes' => 'Bytes',

    'gigabyte_abbr' => '<abbr title="Gigabyte">GB</abbr>',

    'kilobyte_abbr' => '<abbr title="Kilobyte">KB</abbr>',

    'megabyte_abbr' => '<abbr title="Megabyte">MB</abbr>',

    'terabyte_abbr' => '<abbr title="Terabyte">TB</abbr>',

);

// EOF
