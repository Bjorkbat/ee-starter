<?php

$lang = array(

    'check_spelling' => 'Check Spelling',

    'no_spelling_errors' => 'No Errors Found',

    'revert_spellcheck' => 'Revert to Original',

    'save_spellcheck' => 'Save Changes',

    'spell_check' => 'Spell Check',

    'spell_edit_word' => 'Edit Word',

    'spell_save_edit' => 'Save Edit',

    'spellcheck_in_progress' => 'Check In Progress...',

    'unsupported_browser' => 'Unsupported Browser',

);

// EOF
