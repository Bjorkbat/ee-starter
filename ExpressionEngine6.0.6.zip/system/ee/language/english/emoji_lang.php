<?php

$lang = array(

    'emoji_module_name' => 'Emoji',

);

// EOF
