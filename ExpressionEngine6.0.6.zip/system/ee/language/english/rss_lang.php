<?php

$lang = array(

    'rss_invalid_channel' => 'The channel specified in your RSS feed does not exist.',

    'rss_module_description' => 'RSS page generating module',

    'rss_module_name' => 'RSS',

);

// EOF
