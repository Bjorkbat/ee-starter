<?php

$lang = array(

    'fb_insert_file' => 'Insert File',

    'fb_insert_files' => 'Insert Files',

    'fb_insert_link' => 'Insert Link',

    'fb_insert_links' => 'Insert Links',

    'fb_insert_url' => 'Insert URL',

    'fb_insert_urls' => 'Insert URLs',

    'fb_non_images' => '* Indicates non-images. Only images can be viewed.',

    'fb_select_field' => 'Select Field',

    'fb_select_files' => 'Select Files',

    'fb_view_image' => 'View Image',

    'fb_view_images' => 'View Images',

    'file_browser' => 'File Browser',

    'file_viewing_error' => 'An error of an unknown type was encountered.',

    'fp_no_files' => 'No files available in directory.',

    'path_does_not_exist' => 'The specified path does not exist',

    'view' => 'View',

);

// EOF
