<?php

$lang = array(

    /* Custom Publish Tabs - Namespacing the key is highly recommended. */
    'eeof_example' => 'Example Tag!',

);

// EOF
