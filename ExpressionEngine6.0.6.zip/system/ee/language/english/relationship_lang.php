<?php

$lang = array(

    'relationship_module_name' => 'Relationships',

);

// EOF
