<?php

$lang = array(

    'invalid_license' => 'Invalid License',

);

// EOF
