<?php

$lang = array(
    'channel_entry' => 'Channel Entry',

);
// EOF
