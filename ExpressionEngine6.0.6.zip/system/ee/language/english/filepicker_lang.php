<?php

$lang = array(

    'filepicker_module_name' => 'FilePicker',

    'list' => 'list',

    'picker_type' => 'view as',

    'thumbnails' => 'thumbnails',

);

// EOF
