<?php

require SYSPATH . 'ee/ExpressionEngine/Addons/moblog/language/english/moblog_lang.php';
