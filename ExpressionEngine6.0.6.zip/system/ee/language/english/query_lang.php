<?php

$lang = array(

    'query_module_description' => 'SQL query module for templates',

    'query_module_name' => 'Query',

);

// EOF
