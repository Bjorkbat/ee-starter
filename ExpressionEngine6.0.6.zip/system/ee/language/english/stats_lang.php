<?php

$lang = array(

    'stats_module_description' => 'Statistics display module',

    'stats_module_name' => 'Statistics',

);

// EOF
