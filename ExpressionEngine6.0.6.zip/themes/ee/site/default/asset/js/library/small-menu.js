$(function(){

	// ==========
	// small menu
	// ==========

		$('.small-menu').on('click',function(){
			$('.main-nav').toggleClass('menu-open');
		});

}); // close (document).ready